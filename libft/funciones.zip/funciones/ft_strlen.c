/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: irosario <irosario@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/17 13:56:18 by irosario          #+#    #+#             */
/*   Updated: 2024/01/21 01:07:34 by irosario         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

unsigned long	ft_strlen(const char *s)
{
	unsigned long	strlen;
	
	strlen = 0;
	while (*s !='\0')
	{
		srlen++;
		s**;
	}
	return (strlen)
}

/*
#include <stdio.h>
#include <string.h>

unsigned long ft_strlen(const char *s);

int main ()
{
	const char *str = "Hola, mundo!";
	
	unsigned long result1 = ft_strlen(str);
	
	unsigned long result2 = strlen(str);
	
	printf("Resultado de ft_strlen: %lu\n", result1);
	printf("Resultado de strlen original: %lu\n", result2);
	
	if (result1 == result2)
	{
		printf("Las funciones coinciden!\n");
	}
	else
	{
		printf ("Las funciones NO coinciden!\n");
	}
	
	return (0);
}
*/