/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: irosario <irosario@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/07 11:54:22 by irosario          #+#    #+#             */
/*   Updated: 2024/02/07 12:01:47 by irosario         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strchr(const char *s, int c)
{
	char	ch;
	
	ch = (char)c;
	while (*s != '\0')
	{
		if (*s == ch)
				return ((char *)s);
		s++;
	}
	if (ch == '\0')
			return ((char*)s);
	else
			return (0);
}

/*
#include <stdio.h>
#include <string.h>

int main() 
{
    const char *originalStr = "Hello, World!";
    const char *customStr = "Hello, World!";

    int targetChar = 'o';

    char *originalResult = strchr(originalStr, targetChar);

    char *customResult = ft_strchr(customStr, targetChar);

    if ((originalResult == NULL && customResult == NULL) || (originalResult && customResult && *originalResult == *customResult)) {
        printf("¡La función ft_strchr funciona correctamente!\n");
    } else {
        printf("Hay un problema con la función ft_strchr.\n");
    }

    return 0;
}
*/