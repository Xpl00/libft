/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: irosario <irosario@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/30 12:44:36 by irosario          #+#    #+#             */
/*   Updated: 2024/01/30 13:17:05 by irosario         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strdup(const char *s1)
{
	char	*ptr;
	size_t	len;
	
	len = ft_strlen(s1);
	ptr = (char *)ft_calloc(len, sizeof(char));
	ft_memcpy(ptr, s1, len);
	return (ptr);
}

/*
#include <stdio.h>
#include <string.h>

int		main(void)
{
	const char	*original_str = "Hello, world!";
	
	char *custom_strdup_result = ft_strdup(original_str);
	printf("Custom ft_strdup result: %s\n", custom_strdup_result);
	
	if (strcmp(custom_strdup_result, original_strdup_result) == 0)
	{
		printf("La implementacion de ft_strdup es correcta!\n");
	}
	else
	{
		printf("Error: la implementacion de ft_strdup es incorrecta.\n");
	}
	
	free(custom_strdup_result);
	free(original_strdup_result);

	return (0);
}
*/

/*
gcc -c ft_memset.c -o ft_memset.o
gcc -c ft_memcpy.c -o ft_memcpy.o
gcc -c ft_calloc.c -o ft_calloc.o
gcc -c ft_strlen.c -o ft_strlen.o
gcc -c ft_strdup.c -o ft_strdup.o

gcc ft_memset.o ft_memcpy.o ft_calloc.o ft_strlen.o ft_strdup.o -o my_program

./my_program
*/