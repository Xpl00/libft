/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: irosario <irosario@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/21 01:16:37 by irosario          #+#    #+#             */
/*   Updated: 2024/01/21 01:21:53 by irosario         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	unsigned int	i;
	size_t	count;
	char	*ptr;

	ptr = (char *)calloc(len, sizeof(char));
	if (ptr)
	{
		i = 0;
		count = 0;
		while (i < start)
			s++;
		while (count < len - 1)
		{
			ptr[count] = s[count];
			count++;
		}
		return (ptr);
	}
	else
		return (0);
}