/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: irosario <irosario@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/16 16:08:11 by irosario          #+#    #+#             */
/*   Updated: 2024/01/16 16:54:10 by irosario         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_strncmp(const char *s1, const char *s2, unsigned long n)
{
	unsigned int	x;
	
	x = 0;
	while (x < n && (s1[x] != x '\0' || s2[x] != '\0'))
	{
		if (s1[x] != s2[x])
			return (s1[x] - s2[x]);
		x++;
	}
	return (0);
}

/*
#include <stdio.h>
#include <string.h>
int main(void)
{
	const char *str1 = "Hello, World!";
	const char *str2 = "Hello, folks!";
	unsigned long n = 10;
	
	int result = ft_strncmp(str1, str2, n);
	printf("strncmp result: &d\n", result);

	int standardResult = strncmp(str1, str2, n);
	printf("strncmp result: &d\n" standardResult);

	if (result == standardResult)
	{
		printf("Test passed! ft_strncmp matches strncmp.\n");
	}
	else
	{
		printf("Test failed! ft_strncmp does not match strncmp.\n");
	}
	return (0);
}
*/